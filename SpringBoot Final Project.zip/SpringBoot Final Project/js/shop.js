// Shop page manager
class ShopManager {
    constructor() {
        this.apiUrl = 'http://localhost:8080/api';
        this.fruits = [];
        this.filteredFruits = [];
        this.bindEvents();
    }

    bindEvents() {
        // Search functionality
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.filterFruits(e.target.value);
        });
    }

    async loadFruits() {
        try {
            window.app.showLoading();
            
            const response = await fetch(`${this.apiUrl}/fruits`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                this.fruits = await response.json();
                this.filteredFruits = [...this.fruits];
                this.renderFruits();
            } else {
                throw new Error('Failed to load fruits');
            }
            
        } catch (error) {
            console.error('Error loading fruits:', error);
            this.showError('Failed to load fruits. Please check if the server is running.');
        } finally {
            window.app.hideLoading();
        }
    }

    filterFruits(searchTerm) {
        this.filteredFruits = this.fruits.filter(fruit =>
            fruit.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        this.renderFruits();
    }

    renderFruits() {
        const fruitsGrid = document.getElementById('fruits-grid');
        const noResults = document.getElementById('no-results');

        if (this.filteredFruits.length === 0) {
            fruitsGrid.innerHTML = '';
            noResults.classList.remove('hidden');
            return;
        }

        noResults.classList.add('hidden');
        fruitsGrid.innerHTML = this.filteredFruits.map(fruit => this.createFruitCard(fruit)).join('');
    }

    createFruitCard(fruit) {
        const cartItem = window.cartManager.cart.find(item => item.id === fruit.id.toString());
        const quantity = cartItem ? cartItem.quantity : 0;

        return `
            <div class="fruit-card fade-in">
                <div class="fruit-image">
                    <img src="${fruit.image}" alt="${fruit.name}" loading="lazy">
                    <div class="fruit-weight">${fruit.weight}g</div>
                </div>
                <div class="fruit-info">
                    <div class="fruit-name">${fruit.name}</div>
                    <div class="fruit-price">$${parseFloat(fruit.price).toFixed(2)}</div>
                    <div class="fruit-actions">
                        ${quantity === 0 ? 
                            `<button class="add-to-cart-btn" onclick="window.shopManager.addToCart('${fruit.id}')">
                                <i class="fas fa-plus"></i>
                                Add to Cart
                            </button>` :
                            `<div class="quantity-controls">
                                <button class="quantity-btn minus" onclick="window.shopManager.updateQuantity('${fruit.id}', ${quantity - 1})">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <span class="quantity-display">${quantity}</span>
                                <button class="quantity-btn plus" onclick="window.shopManager.updateQuantity('${fruit.id}', ${quantity + 1})">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>`
                        }
                    </div>
                </div>
            </div>
        `;
    }

    addToCart(fruitId) {
        const fruit = this.fruits.find(f => f.id.toString() === fruitId.toString());
        if (fruit && window.cartManager) {
            // Convert fruit data to match cart format
            const cartFruit = {
                id: fruit.id.toString(),
                name: fruit.name,
                price: parseFloat(fruit.price),
                weight: fruit.weight,
                image: fruit.image
            };
            window.cartManager.addToCart(cartFruit);
            this.renderFruits(); // Re-render to update button states
        }
    }

    updateQuantity(fruitId, newQuantity) {
        if (window.cartManager) {
            window.cartManager.updateQuantity(fruitId.toString(), newQuantity);
            this.renderFruits(); // Re-render to update button states
        }
    }

    showError(message) {
        const fruitsGrid = document.getElementById('fruits-grid');
        fruitsGrid.innerHTML = `
            <div class="error-message" style="grid-column: 1 / -1; text-align: center; padding: 40px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: #ef4444; margin-bottom: 16px;"></i>
                <p style="font-size: 18px; color: #374151;">${message}</p>
                <button onclick="window.shopManager.loadFruits()" class="btn btn-primary" style="margin-top: 16px;">
                    Try Again
                </button>
            </div>
        `;
    }
}

// Initialize shop manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.shopManager = new ShopManager();
});