// Main application controller
class FruitShopApp {
    constructor() {
        this.currentUser = null;
        this.currentPage = 'login';
        this.init();
    }

    init() {
        this.checkAuthStatus();
        this.bindEvents();
        this.showPage(this.currentPage);
    }

    checkAuthStatus() {
        const userData = localStorage.getItem('currentUser');
        const token = localStorage.getItem('token');
        
        if (userData && token) {
            this.currentUser = JSON.parse(userData);
            // Determine page based on user role
            if (this.currentUser.role === 'admin') {
                this.currentPage = 'admin';
            } else {
                this.currentPage = 'shop';
            }
        }
    }

    bindEvents() {
        // Auth page navigation
        document.getElementById('show-signup').addEventListener('click', (e) => {
            e.preventDefault();
            this.showPage('signup');
        });

        document.getElementById('show-login').addEventListener('click', (e) => {
            e.preventDefault();
            this.showPage('login');
        });

        // Header navigation
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.logout();
        });

        document.getElementById('admin-btn').addEventListener('click', () => {
            this.showPage('admin');
        });

        // Modal close events
        document.getElementById('close-cart').addEventListener('click', () => {
            document.getElementById('cart-modal').classList.add('hidden');
        });

        document.getElementById('close-edit').addEventListener('click', () => {
            document.getElementById('edit-modal').classList.add('hidden');
        });

        // Close modals on backdrop click
        document.getElementById('cart-modal').addEventListener('click', (e) => {
            if (e.target.id === 'cart-modal') {
                document.getElementById('cart-modal').classList.add('hidden');
            }
        });

        document.getElementById('edit-modal').addEventListener('click', (e) => {
            if (e.target.id === 'edit-modal') {
                document.getElementById('edit-modal').classList.add('hidden');
            }
        });
    }

    showPage(page) {
        // Hide all pages
        document.querySelectorAll('.auth-page, .shop-page, .admin-page').forEach(el => {
            el.classList.add('hidden');
        });

        // Show header for authenticated pages
        const header = document.getElementById('header');
        if (page === 'login' || page === 'signup') {
            header.classList.add('hidden');
        } else {
            header.classList.remove('hidden');
            this.updateHeader();
        }

        // Show requested page
        switch (page) {
            case 'login':
                document.getElementById('login-page').classList.remove('hidden');
                break;
            case 'signup':
                document.getElementById('signup-page').classList.remove('hidden');
                break;
            case 'shop':
                document.getElementById('shop-page').classList.remove('hidden');
                if (window.shopManager) {
                    window.shopManager.loadFruits();
                }
                break;
            case 'admin':
                document.getElementById('admin-page').classList.remove('hidden');
                if (window.adminManager) {
                    window.adminManager.loadFruits();
                }
                break;
        }

        this.currentPage = page;
    }

    updateHeader() {
        if (!this.currentUser) return;

        document.getElementById('username-display').textContent = this.currentUser.username;

        // Show/hide role-specific buttons
        const cartBtn = document.getElementById('cart-btn');
        const adminBtn = document.getElementById('admin-btn');

        if (this.currentUser.role === 'customer') {
            cartBtn.classList.remove('hidden');
            adminBtn.classList.add('hidden');
        } else if (this.currentUser.role === 'admin') {
            cartBtn.classList.add('hidden');
            adminBtn.classList.remove('hidden');
        }
    }

    login(userData) {
        this.currentUser = userData;
        localStorage.setItem('currentUser', JSON.stringify(userData));
        
        // Determine target page based on user role
        const targetPage = userData.role === 'admin' ? 'admin' : 'shop';
        this.showPage(targetPage);
        
        // Initialize cart for customers
        if (userData.role === 'customer' && window.cartManager) {
            window.cartManager.init();
        }
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
        localStorage.removeItem('token');
        
        // Clear cart
        if (window.cartManager) {
            window.cartManager.clearCart();
        }
        
        this.showPage('login');
    }

    showLoading() {
        document.getElementById('loading').classList.remove('hidden');
    }

    hideLoading() {
        document.getElementById('loading').classList.add('hidden');
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new FruitShopApp();
});