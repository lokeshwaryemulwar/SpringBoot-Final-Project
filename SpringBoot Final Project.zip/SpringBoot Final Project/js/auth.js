// Authentication manager
class AuthManager {
    constructor() {
        this.apiUrl = 'http://localhost:8080/api';
        this.bindEvents();
    }

    bindEvents() {
        // Login form
        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Signup form
        document.getElementById('signup-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSignup();
        });

        // Password toggle buttons
        document.querySelectorAll('.password-toggle').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.togglePassword(e.target.closest('.password-group'));
            });
        });
    }

    async handleLogin() {
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        const errorEl = document.getElementById('login-error');
        const submitBtn = document.querySelector('#login-form button[type="submit"]');

        // Clear previous errors
        errorEl.textContent = '';

        // Show loading state
        this.setButtonLoading(submitBtn, true);

        try {
            const response = await fetch(`${this.apiUrl}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
                // Store token and user data
                localStorage.setItem('token', data.token);
                localStorage.setItem('currentUser', JSON.stringify({
                    id: data.id,
                    username: data.username,
                    email: data.email,
                    role: data.role
                }));
                
                window.app.login({
                    id: data.id,
                    username: data.username,
                    email: data.email,
                    role: data.role
                });
            } else {
                errorEl.textContent = data.message || 'Invalid username or password';
            }
        } catch (error) {
            errorEl.textContent = 'Connection error. Please check if the server is running.';
            console.error('Login error:', error);
        } finally {
            this.setButtonLoading(submitBtn, false);
        }
    }

    async handleSignup() {
        const username = document.getElementById('signup-username').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        const confirmPassword = document.getElementById('signup-confirm-password').value;
        const errorEl = document.getElementById('signup-error');
        const submitBtn = document.querySelector('#signup-form button[type="submit"]');

        // Clear previous errors
        errorEl.textContent = '';

        // Validation
        if (password !== confirmPassword) {
            errorEl.textContent = 'Passwords do not match';
            return;
        }

        if (password.length < 6) {
            errorEl.textContent = 'Password must be at least 6 characters long';
            return;
        }

        // Show loading state
        this.setButtonLoading(submitBtn, true);

        try {
            const response = await fetch(`${this.apiUrl}/auth/signup`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, email, password })
            });

            const data = await response.json();

            if (response.ok) {
                // Store token and user data
                localStorage.setItem('token', data.token);
                localStorage.setItem('currentUser', JSON.stringify({
                    id: data.id,
                    username: data.username,
                    email: data.email,
                    role: data.role
                }));
                
                window.app.login({
                    id: data.id,
                    username: data.username,
                    email: data.email,
                    role: data.role
                });
            } else {
                errorEl.textContent = data.message || 'Failed to create account. Please try again.';
            }
        } catch (error) {
            errorEl.textContent = 'Connection error. Please check if the server is running.';
            console.error('Signup error:', error);
        } finally {
            this.setButtonLoading(submitBtn, false);
        }
    }

    togglePassword(passwordGroup) {
        const input = passwordGroup.querySelector('input');
        const icon = passwordGroup.querySelector('.password-toggle i');

        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye';
        }
    }

    setButtonLoading(button, loading) {
        const textEl = button.querySelector('.btn-text');
        const loadingEl = button.querySelector('.btn-loading');

        if (loading) {
            textEl.classList.add('hidden');
            loadingEl.classList.remove('hidden');
            button.disabled = true;
        } else {
            textEl.classList.remove('hidden');
            loadingEl.classList.add('hidden');
            button.disabled = false;
        }
    }

    getAuthHeaders() {
        const token = localStorage.getItem('token');
        return {
            'Content-Type': 'application/json',
            'Authorization': token ? `Bearer ${token}` : ''
        };
    }
}

// Initialize auth manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.authManager = new AuthManager();
});