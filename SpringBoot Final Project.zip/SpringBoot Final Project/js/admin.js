// Admin panel manager
class AdminManager {
    constructor() {
        this.apiUrl = 'http://localhost:8080/api';
        this.fruits = [];
        this.editingFruit = null;
        this.bindEvents();
    }

    bindEvents() {
        // Add fruit button
        document.getElementById('add-fruit-btn').addEventListener('click', () => {
            this.showAddForm();
        });

        // Cancel add button
        document.getElementById('cancel-add').addEventListener('click', () => {
            this.hideAddForm();
        });

        // Add fruit form
        document.getElementById('fruit-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addFruit();
        });

        // Edit fruit form
        document.getElementById('edit-fruit-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateFruit();
        });

        // Cancel edit button
        document.getElementById('cancel-edit').addEventListener('click', () => {
            this.hideEditModal();
        });
    }

    async loadFruits() {
        try {
            window.app.showLoading();
            
            const response = await fetch(`${this.apiUrl}/fruits`, {
                method: 'GET',
                headers: window.authManager.getAuthHeaders()
            });

            if (response.ok) {
                this.fruits = await response.json();
                this.renderFruitsTable();
            } else {
                throw new Error('Failed to load fruits');
            }
            
        } catch (error) {
            console.error('Error loading fruits:', error);
            this.showError('Failed to load fruits. Please check if the server is running.');
        } finally {
            window.app.hideLoading();
        }
    }

    renderFruitsTable() {
        const tbody = document.getElementById('admin-fruits-tbody');
        
        if (this.fruits.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center loading-row">
                        No fruits available. Add some fruits to get started.
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = this.fruits.map(fruit => `
            <tr>
                <td>
                    <img src="${fruit.image}" alt="${fruit.name}" class="fruit-thumbnail">
                </td>
                <td class="fruit-name-cell">${fruit.name}</td>
                <td class="fruit-price-cell">$${parseFloat(fruit.price).toFixed(2)}</td>
                <td class="fruit-weight-cell">${fruit.weight}g</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn edit" onclick="window.adminManager.editFruit('${fruit.id}')" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="window.adminManager.deleteFruit('${fruit.id}')" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    showAddForm() {
        document.getElementById('add-fruit-form').classList.remove('hidden');
        document.getElementById('fruit-name').focus();
    }

    hideAddForm() {
        document.getElementById('add-fruit-form').classList.add('hidden');
        this.clearAddForm();
    }

    clearAddForm() {
        document.getElementById('fruit-form').reset();
    }

    async addFruit() {
        const formData = {
            name: document.getElementById('fruit-name').value,
            price: parseFloat(document.getElementById('fruit-price').value),
            weight: parseInt(document.getElementById('fruit-weight').value),
            image: document.getElementById('fruit-image').value
        };

        // Validation
        if (!formData.name || !formData.price || !formData.weight || !formData.image) {
            this.showMessage('Please fill in all fields.', 'error');
            return;
        }

        try {
            window.app.showLoading();
            
            const response = await fetch(`${this.apiUrl}/fruits`, {
                method: 'POST',
                headers: window.authManager.getAuthHeaders(),
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                const newFruit = await response.json();
                this.fruits.push(newFruit);
                this.renderFruitsTable();
                this.hideAddForm();
                this.showMessage('Fruit added successfully!', 'success');
            } else {
                const error = await response.json();
                this.showMessage(error.message || 'Failed to add fruit.', 'error');
            }
            
        } catch (error) {
            console.error('Error adding fruit:', error);
            this.showMessage('Failed to add fruit. Please try again.', 'error');
        } finally {
            window.app.hideLoading();
        }
    }

    editFruit(fruitId) {
        const fruit = this.fruits.find(f => f.id.toString() === fruitId.toString());
        if (!fruit) return;

        this.editingFruit = fruit;
        
        // Populate edit form
        document.getElementById('edit-fruit-name').value = fruit.name;
        document.getElementById('edit-fruit-price').value = fruit.price;
        document.getElementById('edit-fruit-weight').value = fruit.weight;
        document.getElementById('edit-fruit-image').value = fruit.image;
        
        // Show edit modal
        document.getElementById('edit-modal').classList.remove('hidden');
    }

    hideEditModal() {
        document.getElementById('edit-modal').classList.add('hidden');
        this.editingFruit = null;
    }

    async updateFruit() {
        if (!this.editingFruit) return;

        const formData = {
            name: document.getElementById('edit-fruit-name').value,
            price: parseFloat(document.getElementById('edit-fruit-price').value),
            weight: parseInt(document.getElementById('edit-fruit-weight').value),
            image: document.getElementById('edit-fruit-image').value
        };

        // Validation
        if (!formData.name || !formData.price || !formData.weight || !formData.image) {
            this.showMessage('Please fill in all fields.', 'error');
            return;
        }

        try {
            window.app.showLoading();
            
            const response = await fetch(`${this.apiUrl}/fruits/${this.editingFruit.id}`, {
                method: 'PUT',
                headers: window.authManager.getAuthHeaders(),
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                const updatedFruit = await response.json();
                
                // Update local data
                const index = this.fruits.findIndex(f => f.id === this.editingFruit.id);
                if (index !== -1) {
                    this.fruits[index] = updatedFruit;
                }
                
                this.renderFruitsTable();
                this.hideEditModal();
                this.showMessage('Fruit updated successfully!', 'success');
            } else {
                const error = await response.json();
                this.showMessage(error.message || 'Failed to update fruit.', 'error');
            }
            
        } catch (error) {
            console.error('Error updating fruit:', error);
            this.showMessage('Failed to update fruit. Please try again.', 'error');
        } finally {
            window.app.hideLoading();
        }
    }

    async deleteFruit(fruitId) {
        const fruit = this.fruits.find(f => f.id.toString() === fruitId.toString());
        if (!fruit) return;

        if (!confirm(`Are you sure you want to delete "${fruit.name}"?`)) {
            return;
        }

        try {
            window.app.showLoading();
            
            const response = await fetch(`${this.apiUrl}/fruits/${fruitId}`, {
                method: 'DELETE',
                headers: window.authManager.getAuthHeaders()
            });

            if (response.ok) {
                this.fruits = this.fruits.filter(f => f.id.toString() !== fruitId.toString());
                this.renderFruitsTable();
                this.showMessage('Fruit deleted successfully!', 'success');
            } else {
                this.showMessage('Failed to delete fruit.', 'error');
            }
            
        } catch (error) {
            console.error('Error deleting fruit:', error);
            this.showMessage('Failed to delete fruit. Please try again.', 'error');
        } finally {
            window.app.hideLoading();
        }
    }

    showMessage(message, type) {
        // Create message element
        const messageEl = document.createElement('div');
        messageEl.className = `${type}-message`;
        messageEl.textContent = message;
        
        // Insert at top of admin page
        const container = document.querySelector('.admin-page .container');
        container.insertBefore(messageEl, container.firstChild);
        
        // Remove after 5 seconds
        setTimeout(() => {
            if (messageEl.parentNode) {
                messageEl.parentNode.removeChild(messageEl);
            }
        }, 5000);
    }

    showError(message) {
        const tbody = document.getElementById('admin-fruits-tbody');
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center loading-row">
                    <i class="fas fa-exclamation-triangle" style="font-size: 24px; color: #ef4444; margin-bottom: 8px;"></i>
                    <p>${message}</p>
                    <button onclick="window.adminManager.loadFruits()" class="btn btn-primary" style="margin-top: 8px;">
                        Try Again
                    </button>
                </td>
            </tr>
        `;
    }
}

// Initialize admin manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.adminManager = new AdminManager();
});