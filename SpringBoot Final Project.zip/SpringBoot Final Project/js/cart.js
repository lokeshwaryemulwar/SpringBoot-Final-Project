// Shopping cart manager
class CartManager {
    constructor() {
        this.apiUrl = 'https://localhost:8080/api';
        this.cart = [];
        this.bindEvents();
    }

    init() {
        this.loadCart();
        this.updateCartDisplay();
    }

    bindEvents() {
        // Cart button
        document.getElementById('cart-btn').addEventListener('click', () => {
            this.showCart();
        });

        // Checkout button
        document.getElementById('checkout-btn').addEventListener('click', () => {
            this.checkout();
        });
    }

    loadCart() {
        const cartData = localStorage.getItem('cart');
        if (cartData) {
            this.cart = JSON.parse(cartData);
        }
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.cart));
    }

    addToCart(fruit) {
        const existingItem = this.cart.find(item => item.id === fruit.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({
                ...fruit,
                quantity: 1
            });
        }

        this.saveCart();
        this.updateCartDisplay();
        this.showAddedToCartFeedback(fruit.name);
    }

    updateQuantity(fruitId, newQuantity) {
        if (newQuantity <= 0) {
            this.removeFromCart(fruitId);
            return;
        }

        const item = this.cart.find(item => item.id === fruitId);
        if (item) {
            item.quantity = newQuantity;
            this.saveCart();
            this.updateCartDisplay();
        }
    }

    removeFromCart(fruitId) {
        this.cart = this.cart.filter(item => item.id !== fruitId);
        this.saveCart();
        this.updateCartDisplay();
    }

    clearCart() {
        this.cart = [];
        this.saveCart();
        this.updateCartDisplay();
    }

    getCartItemCount() {
        return this.cart.reduce((total, item) => total + item.quantity, 0);
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    updateCartDisplay() {
        // Update cart count badge
        const cartCount = document.getElementById('cart-count');
        const itemCount = this.getCartItemCount();
        cartCount.textContent = itemCount;
        cartCount.style.display = itemCount > 0 ? 'flex' : 'none';

        // Update cart modal content
        this.renderCartItems();
    }

    renderCartItems() {
        const cartItemsEl = document.getElementById('cart-items');
        const emptyCartEl = document.getElementById('empty-cart');
        const cartFooterEl = document.getElementById('cart-footer');
        const cartTotalEl = document.getElementById('cart-total');

        if (this.cart.length === 0) {
            cartItemsEl.innerHTML = '';
            emptyCartEl.classList.remove('hidden');
            cartFooterEl.classList.add('hidden');
            return;
        }

        emptyCartEl.classList.add('hidden');
        cartFooterEl.classList.remove('hidden');

        cartItemsEl.innerHTML = this.cart.map(item => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                </div>
                <div class="cart-item-controls">
                    <button class="cart-quantity-btn minus" onclick="window.cartManager.updateQuantity('${item.id}', ${item.quantity - 1})">
                        <i class="fas fa-minus"></i>
                    </button>
                    <span class="cart-quantity">${item.quantity}</span>
                    <button class="cart-quantity-btn plus" onclick="window.cartManager.updateQuantity('${item.id}', ${item.quantity + 1})">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
        `).join('');

        cartTotalEl.textContent = this.getCartTotal().toFixed(2);
    }

    showCart() {
        this.renderCartItems();
        document.getElementById('cart-modal').classList.remove('hidden');
    }

    async checkout() {
        if (this.cart.length === 0) return;

        try {
            window.app.showLoading();

            // Prepare order data
            const orderData = {
                items: this.cart.map(item => ({
                    fruitId: parseInt(item.id),
                    quantity: item.quantity
                }))
            };

            const response = await fetch(`${this.apiUrl}/orders`, {
                method: 'POST',
                headers: window.authManager.getAuthHeaders(),
                body: JSON.stringify(orderData)
            });

            if (response.ok) {
                const order = await response.json();
                alert(`Order placed successfully! Order ID: ${order.id}\nTotal: $${parseFloat(order.totalAmount).toFixed(2)}`);
                
                this.clearCart();
                document.getElementById('cart-modal').classList.add('hidden');
            } else {
                const error = await response.json();
                alert('Failed to place order: ' + (error.message || 'Unknown error'));
            }

        } catch (error) {
            console.error('Checkout error:', error);
            alert('Failed to place order. Please check if the server is running.');
        } finally {
            window.app.hideLoading();
        }
    }

    showAddedToCartFeedback(fruitName) {
        // Create temporary feedback element
        const feedback = document.createElement('div');
        feedback.className = 'cart-feedback';
        feedback.textContent = `${fruitName} added to cart!`;
        feedback.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: #4ade80;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            animation: slideIn 0.3s ease-out;
        `;

        document.body.appendChild(feedback);

        // Remove after 3 seconds
        setTimeout(() => {
            feedback.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => {
                if (feedback.parentNode) {
                    document.body.removeChild(feedback);
                }
            }, 300);
        }, 3000);
    }
}

// Initialize cart manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.cartManager = new CartManager();
});