import React from 'react';
import { Plus, Minus } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface Fruit {
  id: string;
  name: string;
  price: number;
  weight: number;
  image: string;
}

interface FruitCardProps {
  fruit: Fruit;
}

const FruitCard: React.FC<FruitCardProps> = ({ fruit }) => {
  const { cart, addToCart, updateQuantity } = useCart();
  
  const cartItem = cart.find(item => item.id === fruit.id);
  const quantity = cartItem?.quantity || 0;

  const handleAddToCart = () => {
    addToCart(fruit);
  };

  const handleIncrement = () => {
    updateQuantity(fruit.id, quantity + 1);
  };

  const handleDecrement = () => {
    updateQuantity(fruit.id, quantity - 1);
  };

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
      <div className="relative">
        <img
          src={fruit.image}
          alt={fruit.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-white rounded-full px-2 py-1 text-sm font-semibold text-green-600">
          {fruit.weight}g
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">{fruit.name}</h3>
        <p className="text-2xl font-bold text-green-600 mb-4">${fruit.price.toFixed(2)}</p>
        
        {quantity === 0 ? (
          <button
            onClick={handleAddToCart}
            className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Plus className="h-5 w-5" />
            <span>Add to Cart</span>
          </button>
        ) : (
          <div className="flex items-center justify-between">
            <button
              onClick={handleDecrement}
              className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-colors"
            >
              <Minus className="h-4 w-4" />
            </button>
            <span className="text-lg font-semibold text-gray-800">{quantity}</span>
            <button
              onClick={handleIncrement}
              className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FruitCard;