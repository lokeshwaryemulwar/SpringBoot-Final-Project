import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X } from 'lucide-react';
import Header from '../components/Header';

interface Fruit {
  id: string;
  name: string;
  price: number;
  weight: number;
  image: string;
}

const AdminPage: React.FC = () => {
  const [fruits, setFruits] = useState<Fruit[]>([]);
  const [isAddingFruit, setIsAddingFruit] = useState(false);
  const [editingFruit, setEditingFruit] = useState<string | null>(null);
  const [newFruit, setNewFruit] = useState({
    name: '',
    price: 0,
    weight: 0,
    image: ''
  });

  useEffect(() => {
    // Mock data - replace with actual API call to Spring Boot backend
    const mockFruits: Fruit[] = [
      {
        id: '1',
        name: 'Red Apple',
        price: 3.99,
        weight: 200,
        image: 'https://images.pexels.com/photos/672101/pexels-photo-672101.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '2',
        name: 'Banana',
        price: 2.49,
        weight: 150,
        image: 'https://images.pexels.com/photos/61127/pexels-photo-61127.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '3',
        name: 'Orange',
        price: 3.29,
        weight: 180,
        image: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '4',
        name: 'Strawberry',
        price: 5.99,
        weight: 100,
        image: 'https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '5',
        name: 'Grapes',
        price: 4.99,
        weight: 250,
        image: 'https://images.pexels.com/photos/23042/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '6',
        name: 'Mango',
        price: 2.99,
        weight: 300,
        image: 'https://images.pexels.com/photos/918040/pexels-photo-918040.jpeg?auto=compress&cs=tinysrgb&w=400'
      }
    ];
    
    setFruits(mockFruits);
  }, []);

  const handleAddFruit = () => {
    if (newFruit.name && newFruit.price > 0 && newFruit.weight > 0) {
      const fruit: Fruit = {
        id: Date.now().toString(),
        ...newFruit
      };
      setFruits([...fruits, fruit]);
      setNewFruit({ name: '', price: 0, weight: 0, image: '' });
      setIsAddingFruit(false);
    }
  };

  const handleDeleteFruit = (id: string) => {
    if (window.confirm('Are you sure you want to delete this fruit?')) {
      setFruits(fruits.filter(fruit => fruit.id !== id));
    }
  };

  const handleUpdateFruit = (id: string, updatedFruit: Partial<Fruit>) => {
    setFruits(fruits.map(fruit => 
      fruit.id === id ? { ...fruit, ...updatedFruit } : fruit
    ));
    setEditingFruit(null);
  };

  const EditableField: React.FC<{
    value: string | number;
    onChange: (value: string | number) => void;
    type?: 'text' | 'number';
    className?: string;
  }> = ({ value, onChange, type = 'text', className = '' }) => {
    return (
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(type === 'number' ? parseFloat(e.target.value) : e.target.value)}
        className={`border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-green-500 ${className}`}
      />
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-orange-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <button
            onClick={() => setIsAddingFruit(true)}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-5 w-5" />
            <span>Add Fruit</span>
          </button>
        </div>

        {/* Add Fruit Form */}
        {isAddingFruit && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Add New Fruit</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={newFruit.name}
                  onChange={(e) => setNewFruit({ ...newFruit, name: e.target.value })}
                  className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="Fruit name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={newFruit.price}
                  onChange={(e) => setNewFruit({ ...newFruit, price: parseFloat(e.target.value) })}
                  className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Weight (g)</label>
                <input
                  type="number"
                  value={newFruit.weight}
                  onChange={(e) => setNewFruit({ ...newFruit, weight: parseInt(e.target.value) })}
                  className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
                <input
                  type="url"
                  value={newFruit.image}
                  onChange={(e) => setNewFruit({ ...newFruit, image: e.target.value })}
                  className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="https://..."
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2 mt-4">
              <button
                onClick={() => setIsAddingFruit(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddFruit}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Add Fruit
              </button>
            </div>
          </div>
        )}

        {/* Fruits Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Image
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Weight (g)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {fruits.map((fruit) => (
                  <tr key={fruit.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <img
                        src={fruit.image}
                        alt={fruit.name}
                        className="h-12 w-12 rounded-lg object-cover"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingFruit === fruit.id ? (
                        <EditableField
                          value={fruit.name}
                          onChange={(value) => handleUpdateFruit(fruit.id, { name: value as string })}
                          className="w-full"
                        />
                      ) : (
                        <div className="text-sm font-medium text-gray-900">{fruit.name}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingFruit === fruit.id ? (
                        <EditableField
                          value={fruit.price}
                          onChange={(value) => handleUpdateFruit(fruit.id, { price: value as number })}
                          type="number"
                          className="w-20"
                        />
                      ) : (
                        <div className="text-sm text-gray-900">${fruit.price.toFixed(2)}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingFruit === fruit.id ? (
                        <EditableField
                          value={fruit.weight}
                          onChange={(value) => handleUpdateFruit(fruit.id, { weight: value as number })}
                          type="number"
                          className="w-20"
                        />
                      ) : (
                        <div className="text-sm text-gray-900">{fruit.weight}g</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        {editingFruit === fruit.id ? (
                          <button
                            onClick={() => setEditingFruit(null)}
                            className="text-green-600 hover:text-green-900"
                          >
                            <Save className="h-4 w-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => setEditingFruit(fruit.id)}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDeleteFruit(fruit.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPage;