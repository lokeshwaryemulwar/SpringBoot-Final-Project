import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import FruitCard from '../components/FruitCard';
import Cart from '../components/Cart';
import { Search } from 'lucide-react';

interface Fruit {
  id: string;
  name: string;
  price: number;
  weight: number;
  image: string;
}

const HomePage: React.FC = () => {
  const [fruits, setFruits] = useState<Fruit[]>([]);
  const [filteredFruits, setFilteredFruits] = useState<Fruit[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    // Mock data - replace with actual API call to Spring Boot backend
    const mockFruits: Fruit[] = [
      {
        id: '1',
        name: 'Red Apple',
        price: 3.99,
        weight: 200,
        image: 'https://images.pexels.com/photos/672101/pexels-photo-672101.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '2',
        name: 'Banana',
        price: 2.49,
        weight: 150,
        image: 'https://images.pexels.com/photos/61127/pexels-photo-61127.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '3',
        name: 'Orange',
        price: 3.29,
        weight: 180,
        image: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '4',
        name: 'Strawberry',
        price: 5.99,
        weight: 100,
        image: 'https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '5',
        name: 'Grapes',
        price: 4.99,
        weight: 250,
        image: 'https://images.pexels.com/photos/23042/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400'
      },
      {
        id: '6',
        name: 'Mango',
        price: 2.99,
        weight: 300,
        image: 'https://images.pexels.com/photos/918040/pexels-photo-918040.jpeg?auto=compress&cs=tinysrgb&w=400'
      }
    ];
    
    setFruits(mockFruits);
    setFilteredFruits(mockFruits);
  }, []);

  useEffect(() => {
    const filtered = fruits.filter(fruit =>
      fruit.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredFruits(filtered);
  }, [searchTerm, fruits]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-orange-50">
      <Header onCartClick={() => setIsCartOpen(true)} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Fresh Fruits Delivered to Your Door
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover our premium selection of fresh, organic fruits. 
            Quality guaranteed, delivered fresh daily.
          </p>
        </div>

        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search fruits..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredFruits.map(fruit => (
            <FruitCard key={fruit.id} fruit={fruit} />
          ))}
        </div>

        {filteredFruits.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">
              No fruits found matching your search.
            </p>
          </div>
        )}
      </main>

      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </div>
  );
};

export default HomePage;