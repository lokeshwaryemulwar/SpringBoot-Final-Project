package com.freshfruit.service;

import com.freshfruit.dto.FruitRequest;
import com.freshfruit.entity.Fruit;
import com.freshfruit.repository.FruitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class FruitService {

    @Autowired
    private FruitRepository fruitRepository;

    public List<Fruit> getAllFruits() {
        return fruitRepository.findAllByOrderByNameAsc();
    }

    public Optional<Fruit> getFruitById(Long id) {
        return fruitRepository.findById(id);
    }

    public List<Fruit> searchFruits(String name) {
        if (name == null || name.trim().isEmpty()) {
            return getAllFruits();
        }
        return fruitRepository.findByNameContainingIgnoreCase(name);
    }

    public Fruit createFruit(FruitRequest fruitRequest) {
        Fruit fruit = new Fruit();
        fruit.setName(fruitRequest.getName());
        fruit.setPrice(fruitRequest.getPrice());
        fruit.setWeight(fruitRequest.getWeight());
        fruit.setImage(fruitRequest.getImage());
        return fruitRepository.save(fruit);
    }

    public Fruit updateFruit(Long id, FruitRequest fruitRequest) {
        Fruit fruit = fruitRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Fruit not found with id: " + id));

        fruit.setName(fruitRequest.getName());
        fruit.setPrice(fruitRequest.getPrice());
        fruit.setWeight(fruitRequest.getWeight());
        fruit.setImage(fruitRequest.getImage());

        return fruitRepository.save(fruit);
    }

    public void deleteFruit(Long id) {
        if (!fruitRepository.existsById(id)) {
            throw new RuntimeException("Fruit not found with id: " + id);
        }
        fruitRepository.deleteById(id);
    }
}