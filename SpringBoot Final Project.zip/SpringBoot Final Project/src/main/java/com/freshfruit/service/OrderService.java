package com.freshfruit.service;

import com.freshfruit.dto.OrderRequest;
import com.freshfruit.entity.Fruit;
import com.freshfruit.entity.Order;
import com.freshfruit.entity.OrderItem;
import com.freshfruit.entity.User;
import com.freshfruit.repository.FruitRepository;
import com.freshfruit.repository.OrderRepository;
import com.freshfruit.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FruitRepository fruitRepository;

    @Transactional
    public Order createOrder(String username, OrderRequest orderRequest) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Order order = new Order();
        order.setUser(user);

        List<OrderItem> orderItems = new ArrayList<>();
        BigDecimal totalAmount = BigDecimal.ZERO;

        for (OrderRequest.OrderItemRequest itemRequest : orderRequest.getItems()) {
            Fruit fruit = fruitRepository.findById(itemRequest.getFruitId())
                    .orElseThrow(() -> new RuntimeException("Fruit not found with id: " + itemRequest.getFruitId()));

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setFruit(fruit);
            orderItem.setQuantity(itemRequest.getQuantity());
            orderItem.setPrice(fruit.getPrice());

            orderItems.add(orderItem);

            BigDecimal itemTotal = fruit.getPrice().multiply(BigDecimal.valueOf(itemRequest.getQuantity()));
            totalAmount = totalAmount.add(itemTotal);
        }

        order.setOrderItems(orderItems);
        order.setTotalAmount(totalAmount);

        return orderRepository.save(order);
    }

    public List<Order> getUserOrders(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return orderRepository.findByUserOrderByCreatedAtDesc(user);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAllByOrderByCreatedAtDesc();
    }
}