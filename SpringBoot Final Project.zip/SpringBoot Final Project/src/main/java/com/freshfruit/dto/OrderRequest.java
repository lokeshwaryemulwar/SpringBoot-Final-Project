package com.freshfruit.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public class OrderRequest {
    @NotEmpty(message = "Order items cannot be empty")
    private List<OrderItemRequest> items;

    // Constructors
    public OrderRequest() {}

    public OrderRequest(List<OrderItemRequest> items) {
        this.items = items;
    }

    // Getters and Setters
    public List<OrderItemRequest> getItems() { return items; }
    public void setItems(List<OrderItemRequest> items) { this.items = items; }

    public static class OrderItemRequest {
        @NotNull(message = "Fruit ID is required")
        private Long fruitId;

        @NotNull(message = "Quantity is required")
        private Integer quantity;

        // Constructors
        public OrderItemRequest() {}

        public OrderItemRequest(Long fruitId, Integer quantity) {
            this.fruitId = fruitId;
            this.quantity = quantity;
        }

        // Getters and Setters
        public Long getFruitId() { return fruitId; }
        public void setFruitId(Long fruitId) { this.fruitId = fruitId; }

        public Integer getQuantity() { return quantity; }
        public void setQuantity(Integer quantity) { this.quantity = quantity; }
    }
}