package com.freshfruit.controller;

import com.freshfruit.dto.FruitRequest;
import com.freshfruit.entity.Fruit;
import com.freshfruit.service.FruitService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/fruits")
public class FruitController {

    @Autowired
    private FruitService fruitService;

    @GetMapping
    public ResponseEntity<List<Fruit>> getAllFruits(@RequestParam(required = false) String search) {
        List<Fruit> fruits;
        if (search != null && !search.trim().isEmpty()) {
            fruits = fruitService.searchFruits(search);
        } else {
            fruits = fruitService.getAllFruits();
        }
        return ResponseEntity.ok(fruits);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Fruit> getFruitById(@PathVariable Long id) {
        return fruitService.getFruitById(id)
                .map(fruit -> ResponseEntity.ok().body(fruit))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Fruit> createFruit(@Valid @RequestBody FruitRequest fruitRequest) {
        try {
            Fruit fruit = fruitService.createFruit(fruitRequest);
            return ResponseEntity.ok(fruit);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Fruit> updateFruit(@PathVariable Long id, @Valid @RequestBody FruitRequest fruitRequest) {
        try {
            Fruit fruit = fruitService.updateFruit(id, fruitRequest);
            return ResponseEntity.ok(fruit);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteFruit(@PathVariable Long id) {
        try {
            fruitService.deleteFruit(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}