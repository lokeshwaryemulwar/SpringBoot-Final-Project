package com.freshfruit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitShoppingBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(FruitShoppingBackendApplication.class, args);
    }
}