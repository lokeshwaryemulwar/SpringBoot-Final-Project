package com.freshfruit.config;

import com.freshfruit.entity.Fruit;
import com.freshfruit.entity.User;
import com.freshfruit.repository.FruitRepository;
import com.freshfruit.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FruitRepository fruitRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create admin user if not exists
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setEmail("admin@freshfruit.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(User.Role.ADMIN);
            userRepository.save(admin);
        }

        // Create customer user if not exists
        if (!userRepository.existsByUsername("customer")) {
            User customer = new User();
            customer.setUsername("customer");
            customer.setEmail("customer@example.com");
            customer.setPassword(passwordEncoder.encode("customer123"));
            customer.setRole(User.Role.CUSTOMER);
            userRepository.save(customer);
        }

        // Create sample fruits if not exists
        if (fruitRepository.count() == 0) {
            fruitRepository.save(new Fruit("Red Apple", new BigDecimal("3.99"), 200, 
                "https://images.pexels.com/photos/672101/pexels-photo-672101.jpeg?auto=compress&cs=tinysrgb&w=400"));
            
            fruitRepository.save(new Fruit("Banana", new BigDecimal("2.49"), 150, 
                "https://images.pexels.com/photos/61127/pexels-photo-61127.jpeg?auto=compress&cs=tinysrgb&w=400"));
            
            fruitRepository.save(new Fruit("Orange", new BigDecimal("3.29"), 180, 
                "https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&w=400"));
            
            fruitRepository.save(new Fruit("Strawberry", new BigDecimal("5.99"), 100, 
                "https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=400"));
            
            fruitRepository.save(new Fruit("Grapes", new BigDecimal("4.99"), 250, 
                "https://images.pexels.com/photos/23042/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400"));
            
            fruitRepository.save(new Fruit("Mango", new BigDecimal("2.99"), 300, 
                "https://images.pexels.com/photos/918040/pexels-photo-918040.jpeg?auto=compress&cs=tinysrgb&w=400"));
        }
    }
}